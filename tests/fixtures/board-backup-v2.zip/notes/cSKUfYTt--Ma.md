## Ausgangslage

Kein Umbau, sondern eine Erweckung — der Sync-Pfad ist heute komplett tot.

**Schnitt:** Logik nach `src/core/sync-service.ts`, `sync.ts` bleibt reine
CLI-Huelle (stdin lesen, parsen, Bericht auf stderr). Sonst bleibt die Datei
nicht unter 300 Zeilen und die Logik ist nur ueber simuliertes stdin testbar.

## a) `TodoItem`-Interface korrigieren

Der echte Payload hat **drei Felder** (Plan Abschnitt 0.1, belegt aus drei
unabhaengigen Quellen — CLI-Binary 2.1.220, RE-Repo fuer 2.1.84, unabhaengiger Gist):

```ts
interface TodoItem {
  content: string;
  status: "pending" | "in_progress" | "completed";
  activeForm: string;   // wird nicht verwendet, steht hier fuer Klarheit
}
```

- `id` entfernen — existiert nicht
- `priority` entfernen — existiert nicht
- **`cancelled` aus `STATUS_TO_COLUMN` (`sync.ts:13`) entfernen** — toter Code,
  der Wert kommt real nie an
- unbekannter `status`-Wert (kuenftige Claude-Code-Version) → `todo`, kein Absturz

## b) Content-Matching, gehaertet

Einzige moegliche Strategie. `source_id` ist gestrichen.

1. exakter Titelvergleich gegen `todo.content`
2. Vergleich gegen die 200-Zeichen-Kuerzung
3. kein Treffer → neuer Task

**Haerten heisst deterministisch werden.** Heute nimmt `existingTasks.find(...)`
(`sync.ts:85`) bei mehreren gleichnamigen Tasks den erstbesten in
Listenreihenfolge — die haengt an `position`, die sich beim Verschieben aendert.
Derselbe Sync trifft also je nach Board-Zustand einen anderen Task. Festlegen:

- bei mehreren Treffern gewinnt der **aelteste nicht archivierte** (`created_at ASC`)
- **archivierte Tasks werden nie getroffen**
- ein in diesem Lauf bereits getroffener Task matcht nicht erneut — sonst
  kollabieren zwei gleichnamige Todos auf einen Task

## c) Eine Transaktion

Gesamte Schleife in `db.transaction(...)`. Heute wird pro Task einzeln
geschrieben; ein Fehler in der Mitte hinterlaesst einen halb synchronisierten Zustand.

## d) Reconcile — unveraendert beschlossen

Sync meldet den Zielzustand, `reconcilePath(ist, soll)` berechnet den Weg, jeder
Zwischenschritt wird als eigene Transition mit `reported_by = "sync"` und
`reason = "reconcile"` protokolliert. Neue Tasks entstehen in `todo` und werden
weiterbewegt, nicht direkt in der Zielspalte angelegt.

Mit dem Wegfall von `cancelled` bleiben drei Zielspalten: `todo`, `in-progress`,
`done`.

**Verschwundene Todos werden ignoriert — bewusst.** TodoWrite ersetzt bei jedem
Aufruf die ganze Liste; ein fehlendes Todo koennte "abgebrochen" heissen oder
schlicht, dass der Agent die Liste gekuerzt hat. Aus dem Payload nicht
unterscheidbar. Der Sync loescht und archiviert nichts.

## e) WIP-Verstoesse: loggen, nicht ablehnen

TodoWrite ist nicht ablehnbar — der Hook laeuft, nachdem der Agent den Zustand
gesetzt hat. Transition mit `was_override = 1`, `reason = "wip-exceeded (sync)"`,
Zeile auf stderr, Warnmarker an der Spalte im TUI.

## f) Keine Priority-Uebernahme

Das Feld existiert nicht. `priority` wird ausschliesslich manuell gesetzt.

## g) Schema-Guard

Meldung auf stderr, **Exit 0** (siehe P0-5).

## Bekannte, nicht behebbare Einschraenkung

Wird ein Task, der aus einem Todo entstanden ist, im TUI umbenannt, erzeugt der
naechste Sync einen zweiten Task. Mit den Daten, die TodoWrite liefert, ist die
Identitaet eines Todos ueber Umbenennungen hinweg prinzipiell nicht
rekonstruierbar. Gehoert in README und CHANGELOG — als Einschraenkung, nicht als
offener Bug.

## Verifikation (`tests/sync-service.test.ts`)

- Titel-Matching, auch gegen die 200-Zeichen-Kuerzung
- **zwei gleichnamige Tasks im Board → der aeltere gewinnt, deterministisch**
- **zwei gleichnamige Todos im selben Payload → zwei Tasks, nicht einer**
- archivierter Task mit passendem Titel wird nicht getroffen
- Reconcile todo → done erzeugt 3 Transitions in richtiger Reihenfolge
- neuer Todo mit `completed` erzeugt 4 Transitions, Task landet in Done
- WIP-Ueberschreitung erzeugt Log statt Abbruch
- Fehler in der Mitte → kein Task geschrieben (Transaktion)
- unbekannter `status`-Wert → `todo`, kein Absturz
- Todo verschwindet aus dem Payload → Task bleibt unveraendert
- Payload ohne `id`/`priority` (also der echte) → laeuft sauber durch

End-to-End mit der Reproduktion aus dem Bugfix-Task: muss
`0 erstellt, 1 verschoben` melden statt zu crashen.