## Geltungsbereich (K-3, entschieden)

**`reportedBy` gilt nur fuer Transitions. Kein `updated_by` auf `tasks`.**

Pflichtfeld in genau vier Tools:
- `kanban_add_task` (`src/mcp/tools.ts:36`)
- `kanban_add_task_checked` (`src/mcp/tools-extras.ts:8`)
- `kanban_move_task` (`tools.ts:123`)
- `kanban_complete_task` (`tools-extras.ts:44`)

**Nicht** anfassen: `kanban_update_task`, `kanban_delete_task`, `kanban_init`,
`kanban_archive_tasks`, alle lesenden Tools.

`kanban_restore_task` erzeugt eine Transition (`reason: "restore"`, siehe P1-1)
und bekommt `reportedBy` dadurch automatisch — dort kein eigener Parameter noetig,
der Wert kommt aus dem Aufrufkontext bzw. faellt auf `"user"` zurueck.

## Schema-Beschreibung — wortgleich in allen vier Tools

```ts
reportedBy: z.string().describe(
  "Wer meldet diese Aenderung? Rollenname des aufrufenden Agents: " +
  "planer, backend, frontend, code-reviewer, teamlead, explorer. " +
  "Bei direkter Nutzung durch den Menschen: user."
)
```

Die Aufzaehlung der Rollennamen ist der eigentliche Trick: ein Agent, der nach
einem freien String gefragt wird, schreibt "claude". Einer, der eine Liste
sieht, waehlt daraus.

**Kein `z.enum`.** Die Rollenliste ist projektspezifisch und aendert sich; ein
Enum wuerde ein fremdes Projekt mit anderen Rollen blockieren.

## CLI und TUI

Optional mit Default `"user"`. Neues Flag `--by <name>` an `add`, `move`, `done`.
In der TUI kein Prompt — dort ist es immer `"user"`.

## Warum der Name so ist

Der Wert ist self-reported und technisch nicht erzwingbar: Claude Code teilt
eine MCP-Verbindung ueber alle Subagenten, der Server kann den Aufrufer nicht
feststellen. `reportedBy` statt `agent` macht das im Namen sichtbar — siehe
ADR 0002, verworfene Alternative "force nur fuer bestimmte Rollen".

## Verifikation

- MCP-Aufruf ohne `reportedBy` → Zod-Validierungsfehler mit verstaendlichem Text
- `transitions.reported_by` enthaelt den uebergebenen Wert
- `kanban_update_task` und `kanban_delete_task` funktionieren **ohne** das Feld
- `kanban move <id> review` ohne `--by` → `reported_by = "user"`
- `kanban move <id> review --by backend` → `reported_by = "backend"`
- README-Tool-Tabelle ergaenzen

## Breaking Change

In den CHANGELOG. Bestehende Agent-Konfigurationen, die diese vier Tools
aufrufen, scheitern bis sie das Feld mitgeben — das ist der Sinn der Sache.