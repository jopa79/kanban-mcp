## Vor jeder Arbeit an 0.2.0 lesen

1. **Plan-Datei (vollstaendig):**
   `.claude/plans/0.2.0-zustandsmaschine-metadaten-multiboard.md`
   — insbesondere **Abschnitt 0.1**, er ist Beleg und darf nicht ueberschrieben werden

2. **ADRs:**
   - `docs/decisions/0001-spalten-in-config-statt-datenbank.md`
   - `docs/decisions/0002-kein-force-in-mcp-tools.md`

3. **Projekt-CLAUDE.md** (Bun statt Node, `bun:sqlite`, `bun test`)

Plan ist **freigegeben und committet**. GitHub-Vorgang: `jopa79/kanban-mcp`, Epic **#2**.

## Alles entschieden ausser K-5

| # | Entscheidung |
|---|---|
| K-1 | `config.json`-Format. **Kein `position`** — die Array-Reihenfolge ist die Ordnung. `allowEntry` am Spaltenobjekt. `done.allowEntry: false`. |
| K-2 | **Ueberfaellig-Marker auf der Karte**, Prioritaet und Datum in der Detailansicht. Zwei Anschlussfragen in **P2-3 delegiert** (TUI-Bearbeitung? Sortierbarkeit?) — dort entscheiden, nicht zurueckgeben. |
| K-3 | `reportedBy` gilt **nur fuer Transitions**. Kein `updated_by` auf `tasks`. |
| K-4 | Registry: nur `path` ist Wahrheit. **Nur `kanban init` registriert, `initBoard()` nicht** — sonst muellt jeder Testlauf die Registry zu. Tote Eintraege markieren, nicht loeschen. Atomar schreiben. |
| E-1 | **TodoWrite liefert weder `id` noch `priority` noch `cancelled`** — belegt. `source_id` gestrichen, P2-4 gestrichen, P1-7 neu zugeschnitten. |
| — | `priority`/`dueDate` bleiben sortierbare Spalten, aber **manuell gepflegt**. |
| E-2 | `kanban sync` sucht **nicht** aufwaerts. |
| E-3 | erledigt — `cancelled` kommt real nie an, toter Code. |
| — | Lizenz **MIT** (committet), npm-Name `kanban-mcp` ist **frei**. |

**Offen: nur K-5** (Transitions-Lebensdauer). Blockiert nichts; wird eingeholt,
wenn Paket 1 anlaeuft.

## Was TodoWrite wirklich liefert

```jsonc
{ "content": "...", "status": "pending" | "in_progress" | "completed", "activeForm": "..." }
```

Kein `id`, kein `priority`, kein `cancelled`. Belegt aus drei unabhaengigen
Quellen (CLI-Binary 2.1.220, RE-Repo fuer 2.1.84, unabhaengiger Gist).

**Folge fuer den Sync:** Content-Matching ist die einzig moegliche Strategie.
Wird ein Task umbenannt, erzeugt der naechste Sync einen zweiten — dokumentierte
Einschraenkung, kein Bug.

## Reihenfolge

```
Paket 0 (Schema v3 + migrate)  ──┬─► Paket 1 (Zustandsmaschine + Sync) ──► Paket 2 (Metadaten)
                                 └─► Paket 3 (Multi-Board, eigener Worktree, parallel)
Paket 4 (Release) nach allem
```

- **Paket 0 blockiert Paket 1 und 2.** Paket 3 haengt nur an P0-1.
- Paket 1 und 2 sequenziell (gleiche Dateien: task-service.ts, types.ts, tools.ts).
- Paket 3 parallel, eigener Worktree (`isolation: "worktree"`).
- P0-7 ist das Abnahmetor vor Paket 1.
- **Naechste Front: P0-1 (#11).** P3-1 (#29) laeuft parallel dazu.

## Kanban ↔ GitHub

| Issue | Task | Stand |
|---|---|---|
| #2 | Epic 0.2.0 (dieser Meta-Task) | offen |
| #3 #4 #5 #6 | K-1, K-2, K-3, K-4 | **geschlossen, entschieden** |
| #7 | K-5 Transitions-Lebensdauer | offen, blockiert nichts |
| #8 #9 #10 | Sync-Bugfix, Payload-Recherche, Typecheck | **geschlossen, committet** |
| #11 – #17 | P0-1 bis P0-7 | offen |
| #18 – #24 | P1-1 bis P1-7 | offen |
| #25 – #27 | P2-1 bis P2-3 | offen |
| ~~#28~~ | ~~P2-4~~ | **gestrichen** |
| #29 – #31 | P3-1 bis P3-3 | offen |
| #32 – #34 | P4-1 bis P4-3 | offen |

Der Kanban ist die Session-Koordination, die Issues sind der dauerhafte Vorgang.

## Was im Repo bereits behoben ist

Committet und gepusht (`4c7aa9a..c84bf06`): Sync-Konstruktorfehler, die 24
Typecheck-Fehler inklusive `purgedCount`/`deletedCount`, LICENSE.

**Was bleibt:** `kanban sync` kommt in der README weiterhin nicht vor, obwohl es
der Hook-Einstiegspunkt ist (P4-1). Und das `TodoItem`-Interface ist weiterhin
falsch — das wird in P1-7 korrigiert, nicht vorher.

Alle diese Fehler sassen in Code, der nie ausgefuehrt oder nie geprueft wurde.
**Ungetesteter Code altert nicht, er verrottet.**

## Riskantester Schritt

`kanban migrate` (Paket 0, #14). Der Tabellen-Neubau von `tasks` zum Entfernen des
columns-Fremdschluessels kann bei aktivem `foreign_keys = ON` die `dependencies`
still wegkaskadieren. Plan Abschnitt 2.3 und Risiko R-1 lesen, bevor eine Zeile
Migration geschrieben wird.