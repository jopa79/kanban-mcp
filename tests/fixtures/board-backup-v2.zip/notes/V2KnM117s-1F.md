## Entschieden (K-4)

`~/.kanban/registry.json`:

```jsonc
{
  "version": 1,
  "boards": [
    { "path": "/Users/joachimpaul/_DEV_/_PROJECTS/kanban-mcp", "name": "kanban-mcp", "registeredAt": "..." }
  ]
}
```

- **Nur `path` ist Wahrheit.** `name` ist ein Cache aus der jeweiligen
  `config.json` und wird beim Lesen aufgefrischt.
- **Nur das CLI-Kommando `kanban init` registriert, `initBoard()` nicht.**
  Das ist die tragende Festlegung: `tests/helpers.ts:24` ruft `initBoard()` bei
  **jedem** Testlauf auf und legt ein temporaeres Board an. Wuerde `initBoard()`
  registrieren, waere die Registry nach einer Woche Entwicklung voller toter
  `/var/folders/...`-Pfade. Dieselbe Trennung schuetzt `importBoard()`.
- `kanban init --no-register` als Ausweg.
- Tote Eintraege werden beim Lesen als `missing` markiert, **nicht geloescht** —
  ein ausgehaengtes Netzlaufwerk ist kein geloeschtes Board. Aufraeumen ueber
  `kanban boards remove`.
- **Atomar schreiben** (tmp + rename), damit zwei gleichzeitig laufende Prozesse
  die Datei nicht zerreissen.

## Neue Dateien

- `src/core/registry-service.ts`
- `src/cli/commands/boards.ts`

```
kanban boards                 # Liste mit aggregiertem Status
kanban boards --json
kanban boards add [pfad]      # default: cwd
kanban boards remove <pfad>
```

Ausgabe:
```
  kanban-mcp        /Users/.../kanban-mcp     12 Tasks   3 in Progress   2 Review
  huespectives-web  /Users/.../hs-web          7 Tasks   1 in Progress   0 Review
  altprojekt        /Users/.../alt           ⚠ Pfad nicht gefunden
  legacy-board      /Users/.../legacy        ⚠ Schema v2 — 'kanban migrate' noetig
```

## Die zwei Fallen

**1. Ein einzelnes kaputtes Board darf die Uebersicht nicht sprengen.**
Fehler **pro Board** abfangen: fehlender Pfad, unlesbares `config.json`,
Schema v2, gelockte DB. Zeile markieren, weitermachen. Ein `try/catch` um die
gesamte Schleife waere falsch — dann verschwinden alle anderen Boards mit.

**2. Nur lesend.** Keine schreibenden Operationen ueber Board-Grenzen hinweg.
Jede DB lesend oeffnen und sofort wieder schliessen; bei vielen Boards nicht
alle gleichzeitig offen halten.

## MCP bleibt aussen vor

**Keine MCP-Tools fuer Boards.** Die Verzeichnisbindung des MCP-Servers ist eine
Isolationsgrenze zwischen Projekten, kein Mangel. `withContext(workingDir, ...)`
(`src/mcp/mcp-context.ts:33`) bleibt unangetastet.

## Verifikation (`tests/registry-service.test.ts`)

- registrieren, doppelt registrieren (idempotent, kein Duplikat), entfernen
- **`initBoard()` registriert nicht** — expliziter Test, sonst kehrt das Problem
  unbemerkt zurueck
- `kanban init --no-register` registriert nicht
- Pfad existiert nicht mehr → als `missing` gelistet, **nicht** entfernt
- Board mit Schema v2 in der Registry → Zeile markiert, kein Absturz
- Board mit kaputtem `config.json` → Zeile markiert, andere Boards weiter sichtbar
- leere Registry → freundliche Meldung, kein Fehler
- `~/.kanban/` existiert nicht → wird angelegt
- `kanban boards --json` parsebar
- nach dem gesamten Testlauf ist die echte `~/.kanban/registry.json` unveraendert