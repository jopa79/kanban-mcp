## Datei

`src/core/export-service.ts` (199 Zeilen)

## Export (v3)

- `EXPORT_VERSION` 2 → 3 (Zeile 11)
- `BoardExport` bekommt `transitions: Transition[]` (Zeile 14-21)
- `columns` **bleiben** im `board.json` — ein Export ist ein vollstaendiger
  Snapshot, auch wenn die Quelle jetzt `config.json` ist. Im ZIP als **geordnetes
  Array ohne `position`-Feld**, analog zur `config.json` (K-1).
- Tasks tragen `priority`, `dueDate`, `sourceId` mit

## Import

**v3:** `columns` → `config.json` (Reihenfolge unveraendert uebernehmen, nicht
sortieren), Transitions → Tabelle, drei neue Task-Felder einspielen.
`insertTask` (Zeile 148-151) erweitern.

**v2 (Pflicht, Rueckwaerts-Kompatibilitaet):**
- `columns[]` aus dem alten `board.json` **nach `position` sortieren**, dann in
  dieser Reihenfolge ins `config.json`-Array schreiben und das `position`-Feld
  weglassen — dieselbe Uebersetzung wie in P0-4, Schritt 4
- `allowEntry` ableiten: die ersten beiden Spalten der sortierten Liste `true`,
  Rest `false`
- `transitions` leer, `priority`/`due_date`/`source_id` NULL
- Board entsteht direkt als v3 — **kein** `kanban migrate` noetig
- Beim Import protokollieren: `v2-Archiv importiert, Spalten nach config.json
  uebernommen, Eintrittsspalten: backlog, todo`

`insertCol` (Zeile 140-146) entfaellt in beiden Faellen — es gibt keine Tabelle mehr.

## Achtung

`importBoard` ruft `createSchema(db)` direkt (Zeile 137) und umgeht damit
`initBoard`. Die Config muss dort separat geschrieben werden (passiert bereits
in Zeile 132) — jetzt aber inklusive Spalten und `schemaVersion`, und durch
`validateBoardConfig` gepruefet, bevor das Board als fertig gilt.

## Verifikation

- v3-Board mit Transitions → export → import in leeres Verzeichnis →
  Tasks, Dependencies, Notes, Transitions, Spalten **inklusive Reihenfolge** identisch
- **Bestehendes v2-ZIP** (aus einem v2-Board erzeugen, bevor migriert wird) →
  import → v3-Board, Spalten in config.json in der richtigen Reihenfolge, ohne
  `position`-Feld, alle Tasks da
- v2-ZIP mit luckenhafter `position` (0, 2, 7) → Reihenfolge korrekt
- `board.json` eines v3-Exports enthaelt `version: 3` und `transitions`
- Export eines v2-Boards wird verweigert (P0-5)