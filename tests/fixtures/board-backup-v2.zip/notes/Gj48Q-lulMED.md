## Root Cause

`src/cli/commands/sync.ts:72`

```ts
const taskService = new TaskService(db, boardService);
```

`ArchiveService` (Basisklasse, `src/core/archive-service.ts:9-13`) verlangt drei
Argumente: `db`, `boardService`, `notesService`. Das dritte fehlt →
`this.notesService` ist `undefined`.

`listTasks()` (`task-service.ts:148`) ruft `this.notesService.exists(...)` →
TypeError. Der Aufruf steht in `sync.ts:79`, also im ersten Schritt jedes Laufs.

## Reproduktion (verifiziert)

```bash
mkdir -p /tmp/synctest && cd /tmp/synctest
bun run <repo>/src/index.ts init "SyncTest"
bun run <repo>/src/index.ts add "Bestehender Task"
echo '{"cwd":"/tmp/synctest","tool_input":{"todos":[{"id":"t1","content":"Neuer Todo","status":"pending","priority":"high"}]}}' \
  | bun run <repo>/src/index.ts sync
```

Ist:  `kanban-mcp sync error: undefined is not an object (evaluating 'this.notesService.exists')`, Exit 1
Soll: `kanban-mcp sync: 1 erstellt, 0 verschoben, 0 uebersprungen`, Exit 0

Bei leerem Board schlaegt es **nicht** zu (leeres `rows`-Array) — deshalb ist
der Fehler nie aufgefallen.

## Fix

```ts
import { NotesService } from "../../core/notes-service.ts";
const paths = getBoardPaths(cwd);
const notesService = new NotesService(paths.kanbanDir);
const taskService = new TaskService(db, boardService, notesService);
```

Vorbild: `src/cli/context.ts:27-32`, `src/mcp/mcp-context.ts:22-27`.

## Verifikation

- Reproduktionsschritte oben, jetzt Exit 0
- `bunx tsc --noEmit` meldet `sync.ts(72,25)` nicht mehr
- Regressionstest anlegen, der die Sync-Schleife gegen ein nicht-leeres Board
  laufen laesst — dass dieser Pfad nie getestet war, ist die eigentliche Ursache