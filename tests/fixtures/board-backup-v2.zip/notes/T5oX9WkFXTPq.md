## Teil 1 — Override-Dialog

Neuer Mode `"confirm-override"` in `src/tui/app.tsx:18`.

Ablauf: Aktion → Ablehnung → Dialog → bei `y` erneut mit `{ override: true }`
→ Transition mit `was_override = 1`.

```
Regel: Aus Todo geht es nur nach In Progress (Ziel waere Review).
Trotzdem verschieben? (y/n)
```

Der Dialog zeigt **den Ablehnungsgrund**, nicht "Bist du sicher?". Ein Dialog
ohne Begruendung wird zum Reflex-Y.

Betroffene Stellen:
- `app.tsx:132-148` — Verschiebe-Modus, Pfeiltasten links/rechts
- `app.tsx:162` — Taste `d` (completeTask)
- `app.tsx:161` — Taste `t` (backlog → todo) ist immer legal, kein Dialog

`use-board.ts` — `moveTask` und `completeTask` muessen den `TransitionCheck`
bis in die Komponente durchreichen, statt zu werfen. Heute schluckt
`writeAndRefresh` (Zeile 66-70) jeden Fehler ungeprueft.

## Teil 2 — Eintrittsregel beim Anlegen

`app.tsx:336-344` legt Tasks in der **aktuell selektierten** Spalte an. Mit `n`
in In Progress zu stehen wird kuenftig abgelehnt.

**Kein Override-Dialog** — hier gibt es nichts zu ueberstimmen, es ist eine
Fehlbedienung. Stattdessen: Task in `todo` anlegen, dorthin springen,
Statuszeile:

```
Neue Tasks nur in Backlog oder Todo — angelegt in Todo
```

## Teil 3 — Dateigroesse

`app.tsx` hat **380 Zeilen** und liegt damit bereits ueber der 300er-Richtgroesse
fuer Komponenten. Deshalb:

- Override-Dialog als eigene Komponente in `status-bar.tsx` (Vorbild:
  `DeleteConfirm`), nicht inline in `app.tsx`
- Modus-Behandlung so knapp wie moeglich
- **Ueber 420 Zeilen: hier stoppen und einen Refactoring-Task anlegen**, nicht
  weiterpatchen. Kandidat waere ein `use-input-modes.ts`, das die
  `useInput`-Kaskade (Zeile 68-176) aus der Komponente holt.

## Verifikation

Manuell in der TUI (mit `vhs` aufzeichnen, falls reproduzierbar noetig):
- Task in Todo, Pfeil rechts, Pfeil rechts → zweiter Move loest Dialog aus
- `n` → Enter → `y` → Task ist in Review, `was_override = 1` in der DB pruefen
- `n` → Enter → `n` → nichts passiert, Task bleibt wo er war
- Esc im Dialog verhaelt sich wie `n`
- In In Progress stehen, `n` druecken, Titel eingeben → Task landet in Todo,
  Statuszeile erklaert warum
- Taste `d` auf einem Task in In Progress → Dialog, nicht stiller Erfolg