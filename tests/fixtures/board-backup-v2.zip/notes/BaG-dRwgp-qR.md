## Umfang — `src/core/task-service.ts`

**`addTask` (Zeile 14)**
- `transitions.canEnter(columnId)` vor dem INSERT
- bei Ablehnung: Fehler mit dem Text aus dem `TransitionCheck`
- nach dem INSERT: Transition mit `from_column = NULL`, `to_column = columnId`
- Default `columnId = "todo"` bleibt (Zeile 17)

**`moveTask` (Zeile 155)**
- Signatur erweitern: `moveTask(id, columnId, opts?: { reportedBy?, reason?, override? })`
- `canMove` pruefen, ausser bei `override: true`
- WIP-Limit der Zielspalte pruefen (`boardService.getColumnTaskCount` gegen
  `column.wipLimit`, `0` = unbegrenzt)
- Transition schreiben, `was_override` setzen

**`completeTask` (Zeile 242)**
- `canComplete` pruefen
- leitet weiter an `moveTask` — dort **nicht** doppelt pruefen

**`restoreTask` (`archive-service.ts:83`)**
- keine Regelpruefung, aber Transition mit `reason: "restore"`

**`archiveTask`, `archiveTasks`, `reorderTask`, `updateTask`, `deleteTask`**
- unveraendert

## Achtung: WIP-Pruefung und Reconcile

Der Sync (P1-7) darf WIP-Verstoesse nicht als Fehler bekommen, sondern muss sie
protokollieren koennen. `moveTask` braucht daher einen Weg, WIP zu melden statt
zu werfen — z.B. `opts.wipPolicy: "reject" | "log"`, Default `"reject"`.
Die Kettenregel bleibt in beiden Faellen hart.

## Breaking Changes (in den CHANGELOG)

1. `addTask` akzeptiert nur noch Spalten mit `allowEntry: true`
2. `moveTask` und `completeTask` koennen ablehnen — `kanban done` scheitert,
   wenn der Task nicht in Review steht

## Bestehende Aufrufer, die jetzt scheitern koennen

| Stelle | Wirkung |
|---|---|
| `src/tui/app.tsx:340` (`n`) | Task in In Progress anlegen → Ablehnung. Behandlung in P1-5. |
| `src/tui/app.tsx:162` (`d`) | Complete ausserhalb Review → Ablehnung. Override in P1-5. |
| `src/tui/app.tsx:132-148` | Verschiebe-Modus, Pfeiltasten. Override in P1-5. |
| `src/cli/commands/add.ts` `-c` | `-c in-progress` scheitert jetzt. In README korrigieren — **das Beispiel steht heute genau so drin.** |
| `scripts/seed-demo.ts` | legt Demo-Tasks vermutlich direkt in mittleren Spalten an → auf Reconcile umstellen oder Override nutzen |

## Verifikation (`tests/task-service-transitions.test.ts`)

- `addTask` in `in-progress`/`review`/`done` scheitert, in `backlog`/`todo` klappt
- `completeTask` aus In Progress scheitert, aus Review klappt
- `moveTask` todo → review scheitert, todo → in-progress klappt
- `moveTask` done → backlog klappt (Rueckwaertssprung)
- Move in volle Spalte (wipLimit 3, 3 Tasks) scheitert; mit `wipPolicy: "log"` nicht
- `override: true` umgeht die Kettenregel und setzt `was_override = 1`
- jede erlaubte Bewegung erzeugt genau eine Transition
- `bun test` — bestehende Tests, die Tasks direkt in mittleren Spalten anlegen,
  muessen umgeschrieben werden. **Nicht die Regel aufweichen, damit alte Tests
  gruen bleiben.**