## Funktion

Neu in `src/core/db.ts`:

```ts
export function findBoardUpwards(startDir: string): string | null
```

Sucht von `startDir` aufwaerts nach `.kanban/board.db`. Grenze: ein Verzeichnis
mit `.git` (dieses wird noch geprueft, dann Abbruch). Zusaetzlich hartes
Abbruchkriterium beim Dateisystem-Root — sonst laeuft die Suche bei einem
Projekt ausserhalb eines Git-Repos bis `/`.

Aufruf aus `src/cli/context.ts:20-25`.

## Gilt fuer

- alle CLI-Kommandos ausser `init` und `sync`
- TUI

## Gilt ausdruecklich NICHT fuer

| Pfad | Grund |
|---|---|
| **MCP-Server** | Die Verzeichnisbindung ist eine Isolationsgrenze zwischen Projekten. Ein MCP-Server in einem Unterverzeichnis darf das Board des Elternprojekts **nicht** sehen. `src/mcp/mcp-context.ts:33` bleibt unangetastet. |
| **`kanban init`** | Sonst legt `init` im Unterverzeichnis ein zweites Board an, waehrend `list` das des Elternverzeichnisses zeigt. `init` arbeitet immer exakt in `cwd`. |
| **`kanban sync`** | **Entschieden (E-2).** Siehe unten. |

## `kanban sync` sucht nicht aufwaerts — entschieden

Der Sync ist technisch ein CLI-Kommando, semantisch ein **automatischer Hook**:
er laeuft unbeaufsichtigt mit einem `cwd`, den Claude Code setzt. Genau die
Konstellation, fuer die die exakte Suche als Isolationsgrenze beibehalten wurde.

Eine Aufwaertssuche wuerde bewirken, dass ein Agent, der in einem Unterprojekt
arbeitet, seine Todos **still** in das Board des Elternprojekts schreibt — ohne
dass es jemand bemerkt, weil der Hook keine sichtbare Ausgabe hat.

`sync.ts` nutzt weiterhin `boardExists(cwd)` exakt und beendet sich mit Exit 0,
wenn dort kein Board liegt (bestehendes Verhalten, `sync.ts:64-67`).

## Verifikation (`tests/find-board.test.ts`)

- Board im Elternverzeichnis wird aus dem Unterverzeichnis gefunden
- `.git` im Elternverzeichnis ohne Board → Suche stoppt dort, `null`
- Board **oberhalb** der `.git`-Grenze wird **nicht** gefunden
- kein Board irgendwo → `null`, keine Endlosschleife bis `/`
- Verzeichnis ohne `.git` und ohne Board → terminiert am Root

Manuell (die drei wichtigsten Tests des Pakets):
- MCP-Server mit `workingDir` = Unterverzeichnis starten → `kanban_status`
  meldet "Kein Board gefunden", **nicht** das Board des Elternprojekts
- `kanban sync` mit `cwd` = Unterverzeichnis ohne eigenes Board → Exit 0,
  **kein** Schreibvorgang im Elternboard
- `kanban init` in einem Unterverzeichnis eines Board-Projekts → legt dort ein
  eigenes Board an, nicht "existiert bereits"