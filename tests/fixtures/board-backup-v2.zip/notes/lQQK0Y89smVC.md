## Warum

`src/cli/commands/sync.ts:16-21` deklariert:

```ts
interface TodoItem {
  id: string;
  content: string;
  status: "pending" | "in_progress" | "completed" | "cancelled";
  priority: "high" | "medium" | "low";
}
```

Diese Deklaration wurde **nie gegen einen echten Payload validiert** — `sync.ts`
ist seit seiner Entstehung nicht fehlerfrei durchgelaufen (siehe Bugfix-Task).
Sie ist eine Annahme, kein Befund.

Zwei Entscheidungen haengen daran:
- `source_id` aus `TodoItem.id` als primaeres Matching (Paket 1)
- `priority` aus `TodoItem.priority` uebernehmen (Paket 2)

Wenn eines der beiden Felder im aktuellen Claude Code gar nicht geliefert wird,
aendert das den Zuschnitt beider Tasks erheblich.

## Vorgehen

1. `kanban sync` temporaer um `--dump <datei>` erweitern: rohes stdin
   unveraendert wegschreiben, dann normal weiterarbeiten.
2. Hook in `.claude/settings.json` auf die Dump-Variante zeigen lassen.
3. In einer normalen Arbeitssession mehrere TodoWrite-Aufrufe ausloesen
   (anlegen, auf in_progress setzen, abschliessen).
4. Payloads auswerten.

## Zu beantworten

- Ist `tool_input.todos[].id` vorhanden? Ist der Wert **ueber mehrere
  TodoWrite-Aufrufe derselben Session hinweg stabil**? Ueber Sessions hinweg?
- Ist `priority` vorhanden? Welche Werte?
- Gibt es Felder, die wir nicht kennen (z.B. `activeForm`)?
- Kommt der Status `cancelled` ueberhaupt vor?
- Ist `cwd` bei Subagenten das Projektverzeichnis oder etwas anderes?

## Ergebnis

Befund als Kommentar in diesen Task und in die Plan-Datei (Risiko R-4,
Einwand E-1). `--dump` danach wieder entfernen — kein Debug-Code im Release.