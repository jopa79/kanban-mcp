## Zu entscheiden

Wie erscheinen `priority` und `dueDate` in der TUI?

**Randbedingung:** `src/tui/task-card.tsx` hat 53 Zeilen und ist schmal — bei
fuenf Spalten nebeneinander bleiben pro Karte wenige Zeichen Breite. Titel und
Blockiert-Marker sind bereits drin.

## Optionen

**A — Farbpunkt auf der Karte**
`● Task-Titel`, Punktfarbe nach Prioritaet (rot/gelb/grau). Kostet 2 Zeichen.
Faelligkeit nur in der Detailansicht.

**B — Randfarbe der Karte**
Kostet keine Breite, aber die Rahmenfarbe markiert heute die Selektion.
Kollision zu klaeren.

**C — Nur Detailansicht**
`detail-view.tsx` (55 Zeilen) bekommt zwei Zeilen. Karte bleibt unveraendert.
Guenstigste Option, aber die Prioritaet ist beim Ueberfliegen unsichtbar.

**D — Ueberfaellig-Marker separat**
Unabhaengig von der Prioritaet: `⚠` oder rote Faerbung bei `isOverdue`.
Empfehlung des Planers: **das ist der wichtigere der beiden Werte auf der Karte.**
Eine Prioritaet kann man nachschlagen, eine verpasste Frist nicht.

## Weiter zu klaeren

- Braucht die TUI eine Bearbeitungsmoeglichkeit (Taste in der Detailansicht),
  oder reicht Setzen ueber CLI und MCP?
- Soll die Board-Ansicht nach Prioritaet sortierbar sein, oder bleibt
  `position` die einzige Ordnung?

Bei Bedarf `ui-ux-pro-max` konsultieren.