## Entscheidung

```json
{
  "name": "Kanban Board",
  "createdAt": "2026-03-03T12:59:44.202Z",
  "schemaVersion": 3,
  "columns": [
    { "id": "backlog",     "name": "Backlog",     "wipLimit": 0, "allowEntry": true,  "isTerminal": false },
    { "id": "todo",        "name": "Todo",        "wipLimit": 0, "allowEntry": true,  "isTerminal": false },
    { "id": "in-progress", "name": "In Progress", "wipLimit": 3, "allowEntry": false, "isTerminal": false },
    { "id": "review",      "name": "Review",      "wipLimit": 0, "allowEntry": false, "isTerminal": false },
    { "id": "done",        "name": "Done",        "wipLimit": 0, "allowEntry": false, "isTerminal": true  }
  ]
}
```

## Die beiden tragenden Festlegungen

**1. `position` entfaellt — die Array-Reihenfolge IST die Reihenfolge.**
Beim Einlesen wird der Index zur Position. Damit bildet die Datei die
Vorwaerts-Regel direkt ab, und es gibt keine Positionsnummern, die von der
tatsaechlichen Reihenfolge abweichen koennen (zwei Spalten mit `position: 2`).
Eine Spalte verschieben heisst eine Zeile verschieben — im git-Diff sofort
lesbar, was der eigentliche Zweck des Umzugs aus der DB ist.

**Konsequenz fuer den Code:** `Column.position` bleibt als **abgeleitetes** Feld
im Domain-Objekt (der Rest des Codes rechnet damit), wird aber aus dem Index
gesetzt und nie aus der Datei gelesen. `validateBoardConfig` muss ein
`position`-Feld in der Datei als **Fehler** melden — sonst glaubt jemand, es
haette eine Wirkung.

**2. `allowEntry` am Spaltenobjekt**, keine separate Eintrittsspalten-Liste,
keine Uebergangsmatrix. Die Kettenregel ist aus dem Index ableitbar:
`zielIndex <= quellIndex + 1`.

`done` steht auf `allowEntry: false`. Andernfalls stuende die
addTask-Hintertuer zur Terminal-Spalte offen und die Regel "Abschluss nur aus
Review" waere mit einem einzigen `addTask({columnId: "done"})` umgangen.

## Validierung (in P0-1 umzusetzen)

- mindestens eine Spalte
- genau eine mit `isTerminal: true`
- mindestens eine mit `allowEntry: true`
- eindeutige `id`
- `position` in der Datei → Fehler
- fehlendes oder unlesbares `config.json` → klare Meldung mit Pfad, kein
  Stacktrace, kein stiller Default

## Umgesetzt in

Plan-Datei Abschnitt 2.1, ADR 0001, Tasks P0-1, P0-2, P1-1.