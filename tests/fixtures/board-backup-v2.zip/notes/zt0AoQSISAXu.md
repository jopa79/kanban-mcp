## Neue Datei

`src/core/transition-service.ts` — **nicht** an `task-service.ts` anbauen.
Die Datei hat 304 Zeilen und naehert sich der 400er-Grenze.

```ts
export interface TransitionCheck {
  allowed: boolean;
  reason?: string;    // handlungsleitender Text, nur wenn !allowed
}

export class TransitionService {
  canMove(task: Task, toColumnId: string): TransitionCheck
  canEnter(columnId: string): TransitionCheck
  canComplete(task: Task): TransitionCheck
  reconcilePath(fromColumnId: string, toColumnId: string): string[]
  log(taskId, from, to, reportedBy, reason, wasOverride): void
  history(taskId: string): Transition[]
}
```

## Die Regel

Aus dem **Array-Index in `config.columns`** abgeleitet (K-1: es gibt kein
`position`-Feld in der Config), **keine Uebergangsmatrix**:

```
zielIndex <= quellIndex + 1   → erlaubt
sonst                          → abgelehnt
```

Rueckspruenge beliebiger Weite sind damit automatisch erlaubt.
`zielIndex == quellIndex` ist ein no-op, kein Fehler.

Praktisch heisst das: `boardService.getColumns()` liefert die Spalten in
Reihenfolge und setzt `position` aus dem Index — die Regel darf entweder mit
`indexOf` auf der Liste oder mit dem abgeleiteten `position` arbeiten, beides
ist dieselbe Zahl. **Nicht** aus der Config-Datei lesen.

`canEnter`: Spalte muss `allowEntry: true` haben. Im Default-Board sind das
`backlog` und `todo` — `done` steht bewusst auf `false`, sonst waere die Regel
"Abschluss nur aus Review" mit einem `addTask({columnId: "done"})` umgangen.

`canComplete`: Task muss in der Spalte direkt vor der Terminal-Spalte stehen
(bei Default-Konfiguration: Review). **Nicht** auf `"review"` hartkodieren —
aus dem Index der Terminal-Spalte ableiten.

`reconcilePath`: Liste der Zwischenspalten von A nach B. Vorwaerts: jede Spalte
dazwischen. Rueckwaerts: direkter Sprung, ein Element.
**Ausschliesslich fuer den Sync.** Sonst ist die Kette Dekoration.

## Ausgenommene Operationen

| Operation | Verhalten |
|---|---|
| `restoreTask` (`archive-service.ts:83`) | keine Regelpruefung, aber Transition mit `reason: "restore"` |
| `archiveTask` | keine Spaltenaenderung → keine Pruefung |
| `reorderTask` | innerhalb der Spalte → keine Pruefung |
| Quelle ist Waisen-Spalte | jeder Move erlaubt, `reason: "orphan-recovery"` |

## Ablehnungstexte

Nicht `Fehler: WIP-Limit erreicht`. Format und WIP-Beispiel: Plan Abschnitt 3.2.
Maßstab: **Kann ein Agent allein aus dem Text den naechsten Schritt ableiten?**

"Blockiert seit" kommt aus der letzten Transition in die Spalte
(`transitions.created_at`), Fallback `tasks.updated_at` fuer Tasks ohne Historie.

## Verifikation (`tests/transition-service.test.ts`)

- jede Spaltenkombination des Default-Boards gegen die Regel (5x5 = 25 Faelle)
- Board mit 3 Spalten und Board mit 7 Spalten → Regel skaliert
- **Spalten in `config.json` umsortieren → Regel folgt der neuen Reihenfolge**
- Terminal-Spalte an anderer Position → `canComplete` folgt mit
- `canEnter("done")` → false
- Waisen-Spalte als Quelle → alles erlaubt
- `reconcilePath("todo","done")` → `["in-progress","review","done"]`
- `reconcilePath("done","todo")` → `["todo"]`
- `log()` schreibt `was_override` korrekt