## Zu entscheiden

Was passiert mit `transitions`-Zeilen von Tasks, die nie archiviert werden?

## Ausgangslage

- `ON DELETE CASCADE` raeumt beim Loeschen eines Tasks auf — aber `deleteTask`
  ist der seltene Fall.
- `archiveTasks` setzt nur ein Flag, loescht nichts. Transitions bleiben.
- `purgeArchive` loescht Tasks hart → Cascade greift → dort ist alles gut.
- **Der Reconcile-Sync ist der eigentliche Treiber:** ein Todo, das erstmals als
  `completed` auftaucht, erzeugt vier Transitions in einer Sekunde
  (Entstehung, todo→in-progress, →review, →done). Bei taeglicher Agenten-Arbeit
  summiert sich das schnell.

## Optionen

**A — unbegrenzt.** Einfach. Eine Zeile ist ~120 Byte; 10.000 Transitions sind
~1,2 MB. Realistisch unproblematisch, aber ohne Obergrenze.

**B — Kappung pro Task** (z.B. die letzten 50). Braucht Aufraeum-Logik bei jedem
Insert. Verliert genau die Historie, die man bei einem lange laufenden Task
sehen will.

**C — `kanban purge-transitions --older-than <tage>`.** Explizit, wie
`purge-archive`. Passt zum Rest des Werkzeugs.

**D — Reconcile-Transitions gesondert behandeln.** Sie tragen
`reason = "reconcile"` und sind die einzigen, die in Massen entstehen.
Sie liessen sich getrennt kappen, ohne die Handarbeit zu verlieren.

**Empfehlung des Planers: A fuer 0.2.0, C+D fuer 0.3.0.** Vorher aber
Sichtbarkeit schaffen — `kanban status` soll die Transitions-Zeilenzahl
ausweisen, damit man ueberhaupt merkt, wenn es zu viel wird.