## Wann entstehen Waisen

- `config.json` von Hand editiert, Spalte entfernt oder umbenannt
- Board mit anderen Spalten importiert
- Migration abgebrochen

Bis v2 verhinderte der Fremdschluessel `tasks.column_id REFERENCES columns(id)`
diesen Zustand. Ab v3 gibt es ihn — siehe ADR 0001.

## Regeln

- **nicht blockieren** — der Task bleibt bearbeitbar
- **nicht automatisch verschieben** — wir wissen nicht, wohin er gehoert
- **nicht verstecken** — ein unsichtbarer Task ist ein verlorener Task

## Umfang

**TUI** (`board-view.tsx`, 128 Zeilen)
Virtuelle Sammelspalte ganz rechts, nur wenn `getOrphanColumnIds()` nicht leer ist:

```
⚠ Ohne Spalte (3)
```

In Warnfarbe (`theme.ts`). Aus dieser Spalte heraus ist jeder Move erlaubt
(`reason: "orphan-recovery"`, siehe P1-1) — das ist der Weg zurueck.

Die Sammelspalte ist virtuell: sie taucht in `board.columns` nicht auf.
`selectedCol`-Navigation (`app.tsx:152-153`) muss sie trotzdem erreichen
koennen. Sauberste Loesung: in `use-board.ts` eine abgeleitete
`displayColumns`-Liste bilden, statt `columns` zu verfaelschen.

**`getStatus()`** (`task-service.ts:294`)
Waisen separat ausweisen. `total` muss sie mitzaehlen, sonst stimmt die Summe
nicht — heute wird `total` aus den Spalten-Zaehlern summiert (Zeile 301) und
wuerde Waisen still verschlucken.

**`kanban status`** (`formatters.ts`)
Zeile `⚠ Ohne Spalte  3` unterhalb der regulaeren Spalten. Auch im `--json`-Modus
(`src/cli/commands/status.ts:16`) — **Achtung, das ist ein Vertrag**:
`plugins/ralph-tracker` liest diese Ausgabe (`plugins/ralph-tracker/src/types.ts:31`).
Ein zusaetzliches Feld ist unkritisch, eine Strukturaenderung nicht.

## Verifikation

- Board anlegen, `config.json` um eine Spalte kuerzen, deren Tasks bestehen →
  TUI zeigt Sammelspalte, `kanban status` weist sie aus, `total` stimmt
- Task aus der Sammelspalte in eine reguläre Spalte verschieben → klappt,
  Transition mit `reason: "orphan-recovery"`
- Board ohne Waisen → keine Sammelspalte, Ausgabe unveraendert
- `kanban status --json` bleibt fuer ralph-tracker lesbar