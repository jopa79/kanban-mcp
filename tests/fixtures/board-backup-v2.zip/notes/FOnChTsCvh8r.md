## Vor der ersten Zeile Code

Plan Abschnitt 2.3 vollstaendig lesen, dazu Risiken R-1, R-2, R-3.

## Dateien

- Neu: `src/core/migrate-v3.ts` (Logik) — **nicht** in `db.ts`, das haette sonst
  zwei Verantwortungen und ~350 Zeilen
- Neu: `src/cli/commands/migrate.ts` (CLI-Huelle)
- `src/index.ts` — Kommando registrieren

```
kanban migrate [--dry-run] [--yes]
```

Ohne Flags: Ist-Version, Ziel-Version, geplante Schritte anzeigen, bestaetigen lassen.
Bereits v3: `Board ist bereits auf Schema-Version 3. Nichts zu tun.`, Exit 0.

## Verbindliche Reihenfolge

```
1. Schema-Version lesen. != 2 → Abbruch mit Erklaerung.
2. Vorpruefung (read-only): columns-Zeilen lesen, Tasks zaehlen, Dependencies zaehlen,
   Waisen zaehlen, config.json parsen. Hat config.json bereits 'columns'?
   → dann ist ein Vorlauf abgebrochen, Schritt 4 ueberspringen.
3. BACKUP: board.db → board.db.bak-v2
4. config.json schreiben (atomar: tmp + rename)
5. config.json ZURUECKLESEN und gegen die DB-Zeilen verifizieren
   → Abweichung = ABBRUCH. Die DB ist hier noch unberuehrt.
6. EINE Transaktion: transitions anlegen, tasks neu bauen, umbenennen,
   Indizes, DROP TABLE columns, schema_version = 3
7. Nachpruefung: Task- und Dependency-Zahlen gegen Schritt 2
8. Bericht
```

## Schritt 4 im Detail — die `position`-Uebersetzung

Die v2-Tabelle hat eine `position`-Spalte, die neue `config.json` hat **keine**
(K-1: die Array-Reihenfolge ist die Reihenfolge). Die Migration uebersetzt:

```sql
SELECT * FROM columns ORDER BY position ASC
```

→ in genau dieser Reihenfolge ins `columns`-Array schreiben, `position`-Feld
dabei **weglassen**.

`allowEntry` ableiten: die ersten beiden Spalten der sortierten Liste `true`,
alle weiteren `false`. Bei einem Default-Board ergibt das `backlog` und `todo`.
Bei abweichend konfigurierten Boards ist das eine Annahme — im Bericht
ausweisen: `Eintrittsspalten gesetzt auf: backlog, todo. Anpassbar in config.json.`

`isTerminal` und `wipLimit` werden 1:1 uebernommen.

**Sonderfall:** Hat kein oder mehr als ein Datensatz `is_terminal = 1`, ist das
Board schon vor der Migration inkonsistent. Abbruch mit Erklaerung, nicht raten.

## Schritt 5 im Detail

Verifiziert wird gegen die **sortierte** DB-Liste:
- Anzahl identisch
- `columns[i].id` == DB-Zeile mit `position`-Rang `i`
- `name`, `wipLimit`, `isTerminal` je Zeile identisch
- genau eine Spalte mit `isTerminal: true`
- mindestens eine mit `allowEntry: true`
- **kein `position`-Feld in der geschriebenen Datei**

## Die drei Fallen

**R-1 — Cascade beim Tabellen-Neubau.** `tasks.column_id` verliert seinen
Fremdschluessel, was in SQLite nur ueber Tabellen-Neubau geht:
`tasks_new` anlegen → kopieren → `DROP TABLE tasks` → `RENAME`. Bei aktivem
`foreign_keys = ON` **kaskadiert `DROP TABLE tasks` die gesamte
`dependencies`-Tabelle weg**. Gegenmassnahme: `PRAGMA foreign_keys = OFF` vor
`BEGIN`, danach wieder `ON` — **und** die Dependency-Zaehlpruefung in Schritt 7.
Beides, nicht eines.

**R-3 — Backup bei aktivem WAL.** Ein `cp board.db` kopiert eine Datei, deren
juengste Transaktionen noch im `-wal` liegen. `VACUUM INTO 'board.db.bak-v2'`
oder die SQLite-Backup-API verwenden. **Kein `Bun.file().write()` auf die
DB-Datei.**

**Backup nie ueberschreiben.** Existiert `board.db.bak-v2` bereits (abgebrochener
Vorlauf), dann `board.db.bak-v2.<timestamp>` anlegen. Ein zweiter Lauf darf das
erste Backup nicht zerstoeren — das ist der Fall, in dem man es am dringendsten
braucht.

## Verifikation (`tests/migrate-v3.test.ts`)

- v2-Board mit Tasks + Dependencies + Notes + archivierten Tasks → migrieren →
  alle Zahlen identisch, Spalten in config.json, `columns`-Tabelle weg
- **Dependency-Zahl vor und nach der Migration identisch** (R-1)
- **Spaltenreihenfolge in config.json entspricht der alten `position`-Ordnung**
- v2-Board mit absichtlich luckenhafter `position` (0, 2, 7) → Reihenfolge
  bleibt korrekt, Luecken verschwinden
- zweimal migrieren → zweiter Lauf meldet "bereits v3", Daten unveraendert
- Abbruch nach Schritt 4 simulieren → erneuter Lauf laeuft durch
- Backup ist ein oeffenbares v2-Board mit allen Tasks
- zweiter Lauf ueberschreibt `board.db.bak-v2` nicht
- Task in nicht existierender Spalte → bleibt erhalten, wird als Waise gemeldet
- Board ohne oder mit zwei Terminal-Spalten → Abbruch mit Erklaerung
- `--dry-run` schreibt nichts (Dateizeitstempel pruefen)