## Vorgehen

1. `.kanban/` des Projekts vollstaendig in ein Temp-Verzeichnis kopieren —
   **inklusive `board.db-wal` und `board.db-shm`**, sonst fehlen die juengsten
   Transaktionen und der Test laeuft gegen unvollstaendige Daten.
2. Vorher-Zahlen erfassen (mit einem v2-faehigen Stand, also vor dem Merge von P0-5,
   oder direkt per `sqlite3`):
   - `SELECT COUNT(*) FROM tasks` (gesamt und `archived = 0`)
   - `SELECT COUNT(*) FROM dependencies`
   - `SELECT COUNT(*) FROM columns`
   - `ls .kanban/notes/*.md | wc -l`
   - Task-IDs als sortierte Liste
3. `kanban migrate --dry-run` im Temp-Verzeichnis → Bericht lesen, plausibel?
4. `kanban migrate`
5. Nachher-Zahlen erfassen und vergleichen. **Task-ID-Listen muessen zeichengleich sein.**
6. `kanban tui` im Temp-Verzeichnis → Board sieht aus wie vorher, alle fuenf
   Spalten, Notizen oeffnen sich
7. `board.db.bak-v2` mit `sqlite3` oeffnen → ist ein vollstaendiges v2-Board
8. `kanban export` → ZIP → in ein drittes Verzeichnis importieren → Zahlen erneut vergleichen

## Abnahmekriterien

- [ ] Task-Anzahl identisch (gesamt und aktiv)
- [ ] **Dependency-Anzahl identisch** — die Stelle, an der R-1 zuschlagen wuerde
- [ ] Task-ID-Liste identisch
- [ ] Spaltenzahl in `config.json` == Zeilenzahl der alten `columns`-Tabelle
- [ ] Notizen-Dateien unveraendert
- [ ] Backup vorhanden und oeffenbar
- [ ] `PRAGMA integrity_check` → `ok`
- [ ] `PRAGMA foreign_key_check` → leer
- [ ] TUI zeigt dasselbe Board

## Erst danach

Erst wenn alle Haken sitzen, migriert JoPa das echte Board. Und auch dann mit
eigenem Backup — nicht nur dem, das die Migration anlegt.

## Ergebnis

Vorher/Nachher-Zahlen als Kommentar in diesen Task. Bei Abweichung: Task
blockiert zurueck, P0-4 aufmachen, nicht "wird schon passen".