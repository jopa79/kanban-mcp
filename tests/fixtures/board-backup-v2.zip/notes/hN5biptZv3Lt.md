## Vor dem Publish — Definition of Done abhaken

- [ ] `bun test` gruen (Altbestand 148 + neue Tests)
- [ ] `bunx tsc --noEmit` **ohne Fehler** (Ausgangslage: 24)
- [ ] `kanban migrate` gegen eine Kopie des echten Boards erfolgreich (P0-7)
- [ ] `kanban sync` mit echtem Hook-Payload lauffaehig (Ausgangslage: Absturz)
- [ ] MCP-Ablehnungen tragen `isError: true` und nennen den naechsten Schritt
- [ ] TUI-Override funktioniert, `was_override` landet in der DB
- [ ] MCP-Server in einem Unterverzeichnis findet kein Board (Isolationsgrenze)
- [ ] v2-ZIP laesst sich importieren
- [ ] README nennt Bun als Voraussetzung, dokumentiert `sync`, `migrate`, `boards`
- [ ] CHANGELOG mit vier Breaking Changes
- [ ] `bun pm pack` → Tarball-Inhalt geprueft
- [ ] Tarball in fremdem Verzeichnis installiert und getestet

## Ablauf

1. Alle Feature-Branches nach `main` gemergt (kein direkter Commit auf `main`)
2. **Freigabe durch JoPa einholen** — Publish ist nicht ruecknehmbar
3. `npm publish` (bzw. `--access public` bei Scope)
4. In einem leeren Verzeichnis: `npx kanban-mcp --version` mit installiertem Bun
5. Erst wenn das laeuft: `git tag v0.2.0 && git push --tags`

Die Reihenfolge ist Absicht: ein Tag auf einen Stand, der sich nicht
veroeffentlichen liess, muss wieder weg.

## Danach

- **`kanban migrate` auf allen eigenen Boards ausfuehren.** Solange nicht
  migriert ist, laeuft der Sync-Hook bei jedem TodoWrite ins Leere und die
  Meldung geht im Rauschen unter (Einwand E-5 in der Plan-Datei).
- Boards suchen: `locate .kanban` bzw. `fd -H '^\.kanban$' ~`
- Alle GitHub-Issues des Releases schliessen
- CHANGELOG bekommt einen frischen `[Unreleased]`-Abschnitt