## Umfang

- Neue Taste `B`: Board-Auswahl (Liste aus der Registry, Enter waehlt, Esc zurueck)
- Neue Komponente `src/tui/board-picker.tsx` — **nicht** in `app.tsx` inline
  (die Datei ist mit 380 Zeilen bereits ueber der Richtgroesse und waechst in
  P1-5 weiter)
- Aggregierter Ueberblick in der Auswahlliste: pro Board Task-Zahlen wie bei
  `kanban boards`
- `workingDir` wird zustandsbehaftet statt Prop — heute kommt es als `AppProps`
  (`app.tsx:20-22`) von `src/cli/commands/tui.ts` herein

## Die zwei Fallen

**1. Der fs.watch-Watcher.**
`use-board.ts:52-63` haengt am `workingDir` und wird in einem `useEffect` mit
`[workingDir, refresh]` neu aufgebaut. Beim Wechsel muss der alte Watcher
**geschlossen** werden — die Cleanup-Funktion (Zeile 62) tut das bereits, aber
nur wenn `workingDir` wirklich Teil des State ist und nicht ein umgangener Prop.
Sonst zeigt Board B die Aenderungen von Board A.

**2. Zustand zuruecksetzen.**
`selectedCol`, `selectedRow`, `filterText`, `detailTask`, `moving` (`app.tsx:28-35`)
gehoeren zum alten Board. Beim Wechsel alle zuruecksetzen — sonst zeigt die
Detailansicht einen Task, den es im neuen Board nicht gibt.

## Randfaelle

- Board in der Registry hat Schema v2 → Auswahl zeigt Warnung, wechselt nicht
- Pfad existiert nicht mehr → ausgegraut, nicht waehlbar
- Registry leer → Hinweis auf `kanban boards add`
- Nur ein Board registriert → Auswahl trotzdem oeffnen, kein Sonderfall

## Verifikation

Manuell mit mindestens drei registrierten Boards:
- `B` → Auswahl → anderes Board → Board wird angezeigt, Zaehler stimmen
- Nach dem Wechsel: Task im **alten** Board ueber CLI aendern → TUI reagiert
  **nicht** (Watcher haengt am neuen Board)
- Nach dem Wechsel: Task im **neuen** Board ueber CLI aendern → TUI aktualisiert
- Filter im alten Board setzen, wechseln → Filter ist weg
- Detailansicht offen, `q`, `B`, wechseln → kein Absturz
- v2-Board in der Liste → Warnung, kein Wechsel