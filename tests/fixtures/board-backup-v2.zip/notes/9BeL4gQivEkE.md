## Teil 1 — kein force fuer harte Regeln

Kettenverstoss, gesperrte Eintrittsspalte, `complete` ausserhalb Review und
WIP-Ueberschreitung bekommen **keinen** `force`-Parameter in MCP-Tools.
Begruendung: `docs/decisions/0002-kein-force-in-mcp-tools.md`.

## Teil 2 — jede Ablehnung traegt isError: true

`src/mcp/tools-extras.ts:33` gibt heute eine Ablehnung **ohne** `isError`
zurueck. Ein Agent liest das als Erfolg und macht weiter. Alle
Ablehnungspfade in `tools.ts`, `tools-extras.ts`, `tools-archive.ts`
durchgehen und pruefen.

## Teil 3 — `kanban_add_task_checked` (`tools-extras.ts:8-41`)

`force` **bleibt** — die Duplikat-Erkennung ist eine Heuristik
(`src/core/similarity.ts`, Trigram) und kann falsch liegen. Ein WIP-Zaehler
kann das nicht. Aber:

**a)** `force` raus aus der Tool-Beschreibung (Zeile 12).
Heute: *"Verwende force=true um trotzdem zu erstellen."* — das ist eine
Einladung.

**b)** `force` raus aus dem Ablehnungstext (Zeile 33) **und** aus
`task-service.ts:88` (`"Verwende --force zum Erstellen."`). Beide Stellen.

**c)** Ablehnung bekommt `isError: true`.

**d)** Antwort nennt **Titel und IDs**:

```
Abgelehnt: aehnliche Tasks existieren bereits.
  [a1b2c3d4] "Sync-Umbau auf Reconcile" (in-progress)
  [e5f6g7h8] "Sync umbauen"             (todo)
Pruefe, ob einer davon dein Anliegen abdeckt.
```

Die IDs sind der Punkt: ohne sie kann der Agent den bestehenden Task nicht
oeffnen und muss raten.

**e)** Der Parameter bleibt im Schema, nur ohne werbendes `.describe()`.
Wer ihn braucht, weiss von ihm.

**f)** `tools-extras.ts:35` — `result.task` ist moeglicherweise `null`
(Typfehler, siehe Typecheck-Task). Beim Umbau gleich sauber machen.

## Verifikation

- Move todo → review ueber MCP → `isError: true`, Text nennt `in-progress`
  als naechsten Schritt
- `kanban_complete_task` auf einen Task in In Progress → `isError: true`
- `kanban_add_task` mit `columnId: "done"` → `isError: true`
- `kanban_add_task_checked` mit aehnlichem Titel → `isError: true`, Antwort
  enthaelt IDs, Wort "force" kommt **nirgends** vor
- `grep -rn "force" src/mcp/` → nur der Parameter selbst, keine Erwaehnung in
  Beschreibungen oder Meldungen