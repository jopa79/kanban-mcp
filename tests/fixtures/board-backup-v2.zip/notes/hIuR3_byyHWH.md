## CLI

**`src/cli/commands/add.ts`**
```
-p, --priority <high|medium|low>
    --due <YYYY-MM-DD>
```

**`src/cli/commands/list.ts`**
```
    --priority <high|medium|low>
    --overdue
    --sort <priority|due|position>
```

**Neu: `kanban update <id>`** — es gibt heute **kein** CLI-Kommando zum Aendern
eines Tasks (`update` fehlt in `src/index.ts:28-44`), nur `note`. Ohne das
laesst sich eine Prioritaet nachtraeglich nur ueber MCP oder TUI setzen.
Entweder hier mitliefern oder bewusst weglassen und in der README erwaehnen.
**Empfehlung: mitliefern**, es sind ~30 Zeilen nach dem Muster von `move.ts`.

**`src/cli/formatters.ts`** — `formatTask` um Prioritaets- und
Faelligkeitsmarker erweitern. Ueberfaellig in Rot.

## MCP

- `kanban_add_task` (`tools.ts:36`) und `kanban_add_task_checked`
  (`tools-extras.ts:8`): `priority`, `dueDate` optional
- `kanban_update_task` (`tools.ts:146`): dito, `nullable` zum Zuruecksetzen
- `kanban_list_tasks` (`tools.ts:99`): Filter `priority`, Flag `overdue`
- `kanban_get_task` liefert `priority`, `dueDate`, `isOverdue` mit — passiert
  automatisch ueber `rowToTask`, aber verifizieren

`.describe()`-Texte knapp und eindeutig: `"Prioritaet: high, medium oder low"`,
`"Faelligkeit als YYYY-MM-DD"`.

## Achtung: JSON-Vertrag

`kanban list --json` und `kanban status --json` werden von
`plugins/ralph-tracker` gelesen (`plugins/ralph-tracker/src/tracker.ts:45`,
`types.ts:31`). Zusaetzliche Felder sind unkritisch — vorhandene umbenennen
oder entfernen waere ein Bruch. Nichts anfassen, nur ergaenzen.

## Verifikation

- `kanban add "Test" -p high --due 2026-08-01` → `kanban get` zeigt beides
- `kanban add "Test" -p urgent` → Fehler mit den drei gueltigen Werten
- `kanban list --overdue` gegen ein Board mit vergangenen **und** zukuenftigen
  Faelligkeiten
- `kanban list --sort priority` → high zuerst, ohne Prioritaet zuletzt
- MCP `kanban_get_task` liefert `isOverdue`
- `kanban list --json | bun -e "JSON.parse(...)"` bleibt parsebar
- ralph-tracker-Tests laufen weiter (`bun test plugins/`)