## Zu entscheiden

**1. Format von `~/.kanban/registry.json`**

Vorschlag:

```jsonc
{
  "version": 1,
  "boards": [
    { "path": "/Users/joachimpaul/_DEV_/_PROJECTS/kanban-mcp", "name": "kanban-mcp", "registeredAt": "..." }
  ]
}
```

Nur `path` ist Wahrheit; `name` ist ein Cache aus der jeweiligen `config.json`
und wird beim Lesen aufgefrischt.

**2. Registriert `kanban init` automatisch?**

| dafuer | dagegen |
|---|---|
| ohne Automatik bleibt die Registry leer und das Feature ungenutzt | `init` schreibt dann ausserhalb des Projektverzeichnisses — bisher tut das kein Kommando |
| kein Extraschritt | Testboards und Wegwerf-Verzeichnisse muellen die Registry zu (die Tests legen bei jedem Lauf temporaere Boards an!) |

**Empfehlung: ja, aber mit Ausnahme.** `initBoard()` registriert nicht — das
CLI-Kommando `kanban init` tut es. Damit bleiben `tests/helpers.ts` und
`importBoard()` aussen vor, die beide `initBoard`/`createSchema` direkt nutzen.
Zusaetzlich `kanban init --no-register`.

**3. Umgang mit toten Eintraegen**

Empfehlung: beim Lesen als `missing` markieren, **nicht** automatisch entfernen.
Ein ausgehaengtes Netzlaufwerk ist kein geloeschtes Board. Aufraeumen ueber
`kanban boards remove`.

**4. Nebenlaeufigkeit**

Zwei Prozesse, die gleichzeitig registrieren, duerfen die Datei nicht zerreissen.
Empfehlung: atomar schreiben (tmp + rename), wie bei `config.json`.