## Zielformat (K-1, entschieden)

```json
{
  "name": "Kanban Board",
  "createdAt": "...",
  "schemaVersion": 3,
  "columns": [
    { "id": "backlog",     "name": "Backlog",     "wipLimit": 0, "allowEntry": true,  "isTerminal": false },
    { "id": "todo",        "name": "Todo",        "wipLimit": 0, "allowEntry": true,  "isTerminal": false },
    { "id": "in-progress", "name": "In Progress", "wipLimit": 3, "allowEntry": false, "isTerminal": false },
    { "id": "review",      "name": "Review",      "wipLimit": 0, "allowEntry": false, "isTerminal": false },
    { "id": "done",        "name": "Done",        "wipLimit": 0, "allowEntry": false, "isTerminal": true  }
  ]
}
```

**Kein `position` in der Datei.** Die Array-Reihenfolge ist die Reihenfolge; der
Index wird beim Laden zur Position.

## Umfang

**`src/core/types.ts`**
- `BoardConfig`: `schemaVersion: number`, `columns: ColumnConfig[]`
- Neuer Typ `ColumnConfig` = `{ id, name, wipLimit, allowEntry, isTerminal }` —
  **ohne** `position`
- `Column` (Domain-Objekt) behaelt `position` und bekommt `allowEntry`.
  `position` wird beim Laden aus dem Array-Index gesetzt, nie aus der Datei gelesen.
- `ColumnRow` und `rowToColumn` entfallen — es gibt keine `columns`-Tabelle mehr

**Neue Funktion `validateBoardConfig(raw: unknown): BoardConfig`**
- mindestens eine Spalte
- genau eine mit `isTerminal: true`
- mindestens eine mit `allowEntry: true`
- eindeutige `id`
- **ein `position`-Feld in der Datei ist ein Fehler**, kein ignoriertes Extra.
  Sonst glaubt jemand, es haette eine Wirkung, und wundert sich ueber die
  Spaltenreihenfolge.

**`src/core/db.ts`**
- `DEFAULT_COLUMNS` (Zeile 10-16) wandert in die Config-Erzeugung, `position`
  raus, `allowEntry` rein: backlog/todo `true`, Rest `false`
- `initBoard()` (Zeile 132) schreibt Spalten in die `config.json`, legt keine
  `columns`-Tabelle mehr an
- `seedColumns()` (Zeile 121) entfaellt ersatzlos
- `createSchema()` legt `columns` nicht mehr an, `tasks.column_id` ohne
  `REFERENCES columns(id)`
- `SCHEMA_VERSION` 2 → 3
- **`migrateDb()` aus `openDb()` entfernen** — Migration laeuft nur noch ueber
  `kanban migrate` (P0-4). `openDb()` macht nur noch PRAGMAs.

**Config-Laden zentralisieren.** Heute steht `JSON.parse(readFileSync(configPath))`
viermal im Code: `cli/context.ts:29`, `mcp/mcp-context.ts:24,40`,
`export-service.ts:31`. Alle vier auf `loadBoardConfig(paths.configPath)` mit
Validierung umstellen. Fehlermeldung nennt Pfad und Grund, kein Stacktrace.

## Verifikation

- `bun test` — `tests/db.test.ts:62,71` erwarten die `columns`-Tabelle und
  muessen umgeschrieben werden (Spalten aus config.json pruefen)
- Neues Board via `kanban init` → `config.json` enthaelt fuenf Spalten ohne
  `position`, DB hat keine `columns`-Tabelle, `schema_version` = 3
- `getColumns()[2].position === 2` — Index korrekt uebernommen
- Spalten in der Datei umsortieren → Reihenfolge im Board folgt sofort
- Kaputte Configs: fehlendes `columns`, leeres Array, zwei Terminal-Spalten,
  kein `allowEntry`, doppelte `id`, vorhandenes `position` → je eine
  verstaendliche Fehlermeldung mit Pfad

## Parallelisierbar mit

Bugfix sync-Konstruktor, Hook-Payload-Recherche, Typecheck-Bereinigung.