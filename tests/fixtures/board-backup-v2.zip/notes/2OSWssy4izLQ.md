## Status
- [x] Export Service
- [x] Import Service
- [ ] MCP Tools registrieren
- [ ] CLI Commands

## Architektur
Export erzeugt ein ZIP mit board.db + notes/.
Import erkennt ob bereits ein Board existiert
und fragt ggf. nach Ueberschreiben.

## Offene Fragen
- Sollen Labels beim Import gemergt werden?
- Max. ZIP-Groesse begrenzen?