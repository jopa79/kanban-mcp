## package.json

```jsonc
{
  "version": "0.2.0",
  "private": false,
  "bin": { "kanban": "./src/index.ts" },
  "files": ["src", "README.md", "CHANGELOG.md", "LICENSE"],
  "engines": { "bun": ">=1.2.0" }
}
```

`src/index.ts:1` hat bereits `#!/usr/bin/env bun` — bleibt so. Das Paket ist
Bun-only (`bun:sqlite`, `Bun.$`), ein Node-Shebang waere gelogen.

## Version an DREI Stellen

Heute stehen sie zufaellig gleich, das haelt nicht:
- `package.json` — `"version": "0.1.0"`
- `src/index.ts:25` — `.version("0.1.0")`
- `src/mcp/server.ts:9` — `version: "0.1.0"`

Alle drei anfassen. **Besser:** aus `package.json` importieren
(`import pkg from "../package.json" with { type: "json" }`) — Bun kann das,
und dann gibt es nur noch eine Quelle. Falls das mit `files` und dem
Build-Output kollidiert, wenigstens einen Test anlegen, der die drei
vergleicht.

## Vor dem Publish zu klaeren

- Ist der npm-Name `kanban-mcp` frei? `npm view kanban-mcp`.
  Falls nicht: Scope `@jopa/kanban-mcp` (dann `publishConfig.access: "public"`).
- `LICENSE`-Datei existiert? Ohne Lizenz ist ein oeffentliches Paket
  rechtlich unklar. `"license"`-Feld fehlt in der package.json ebenfalls.
- Fehlt `repository`, `bugs`, `homepage` — npm zeigt sonst keine Links.

## Verifikation

- `bun pm pack` → Tarball entpacken, Inhalt pruefen: **kein** `.kanban/`,
  keine `node_modules`, keine `docs/*.png`, keine `tests/`
- `kanban --version` → `0.2.0`
- MCP-Server meldet `version: "0.2.0"` im Handshake
- `bun run build` laeuft weiterhin durch
- In einem fremden Verzeichnis: Tarball global installieren, `kanban --help`
  aufrufen, `kanban init` ausfuehren