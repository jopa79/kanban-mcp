## Umfang

**`src/core/types.ts`**
- `Task`: `priority: "high"|"medium"|"low"|null`, `dueDate: string|null`,
  `isOverdue?: boolean`
- `AddTaskInput` / `UpdateTaskInput`: `priority?`, `dueDate?`
- `ListTasksFilter`: `priority?`, `overdue?`
- `rowToTask` ergaenzen

**`src/core/task-service.ts`**
- `addTask` INSERT, `updateTask` SET
- `listTasks` (Zeile 118): Filter `priority`, Filter `overdue`, Sortierung
- `isOverdue` in `getTask` und `listTasks` setzen (analog `isBlocked`, Zeile 113/150)

## Sortierung

```sql
ORDER BY CASE priority
  WHEN 'high' THEN 0 WHEN 'medium' THEN 1 WHEN 'low' THEN 2 ELSE 3 END,
  position ASC, created_at ASC
```

Tasks ohne Prioritaet sortieren **ans Ende**, nicht als "medium".
`null` heisst "nicht gesetzt", nicht "mittel".

Sortierung ist optional (`sort`-Parameter), Default bleibt `position ASC, created_at ASC`
(Zeile 143) — sonst zerreisst es die manuelle Reihenfolge in der TUI.

## Validierung

- `priority`: nur die drei Werte. Fehlermeldung zaehlt die gueltigen auf.
- `dueDate`: `YYYY-MM-DD` **und Kalendergueltigkeit** — `2026-02-31` ist
  syntaktisch korrekt und trotzdem falsch. `new Date(s)` prueft das nicht
  zuverlaessig; Rueckvergleich der formatierten Ausgabe.
- Vergangene Faelligkeiten sind **erlaubt** — man traegt auch ueberfaellige
  Dinge nach.

## `isOverdue` (abgeleitet, nicht gespeichert)

```
dueDate < heute  &&  !archived  &&  Spalte ist nicht terminal
```

Ein erledigter Task ist nicht ueberfaellig. Vergleich auf Datumsebene, nicht
Zeitstempel — ein heute faelliger Task ist heute nicht ueberfaellig.

## Verifikation (`tests/task-metadata.test.ts`)

- Setzen, Lesen, Aendern, auf `null` zuruecksetzen
- ungueltige Prioritaet → Fehler mit Aufzaehlung
- `2026-02-31`, `2026-13-01`, `01.03.2026` → Fehler
- `2026-02-29` (Schaltjahr) → gueltig
- Sortierung: high vor medium vor low vor null
- `isOverdue`: gestern faellig → true; heute faellig → false; gestern faellig
  aber in Done → false; gestern faellig aber archiviert → false