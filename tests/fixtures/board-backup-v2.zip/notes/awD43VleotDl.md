## Entschieden (K-2)

**Ueberfaellig-Marker auf der Karte, Prioritaet und Faelligkeitsdatum in der
Detailansicht.**

Begruendung: eine Prioritaet kann man nachschlagen, eine verpasste Frist nicht.
Bei fuenf Spalten nebeneinander geht jedes Zeichen auf der Karte vom Titel ab —
der knappe Platz gehoert dem Wert, den man nirgends sonst findet.

## Zwei Fragen, die HIER zu entscheiden sind

Vom Teamlead bewusst in diesen Task delegiert. Detailfragen, keine Architektur —
bei Bedarf `ui-ux-pro-max` konsultieren, aber nicht zurueckdelegieren.

**1. Braucht die TUI eine Bearbeitungsmoeglichkeit fuer Prioritaet und
Faelligkeit, oder reichen CLI und MCP?**

Dafuer: die Detailansicht kann heute schon Titel (`T`), Beschreibung (`b`),
Tags (`t`) und Notizen (`e`) — zwei Felder, die man nur ausserhalb setzen kann,
sind ein Bruch im Muster.
Dagegen: `app.tsx` ist mit 380 Zeilen bereits ueber der Richtgroesse und waechst
durch den Override-Dialog aus P1-5 weiter. Zwei neue Eingabemodi kosten dort
Substanz.
Falls ja: als eigene Komponenten in `status-bar.tsx`, **nicht** inline in
`app.tsx`. Prioritaet braucht keinen Texteditor, sondern eine Auswahl aus drei
Werten plus "keine" — naeher an `TagPicker` als an `TitleInput`.

**2. Wird die Board-Ansicht nach Prioritaet sortierbar, oder bleibt `position`
die einzige Ordnung?**

Achtung: `position` traegt die manuelle Reihenfolge, die JoPa im
Verschiebe-Modus (Leertaste + Pfeiltasten) selbst gesetzt hat. Eine
Prioritaets-Sortierung als Ansichtsmodus ist unkritisch; eine, die `position`
ueberschreibt, zerstoert Handarbeit. Wenn sortierbar, dann rein visuell und
umschaltbar — und im Verschiebe-Modus abgeschaltet, sonst springt die Karte
unter dem Cursor weg.

## Umfang

- `src/tui/task-card.tsx` (53 Zeilen) — Ueberfaellig-Marker
- `src/tui/detail-view.tsx` (55 Zeilen) — Prioritaet und Faelligkeit im Klartext
- `src/tui/theme.ts` (62 Zeilen) — Farben fuer overdue und die drei Prioritaeten

## Verifikation

- Board mit Tasks in allen drei Prioritaeten, mit und ohne Faelligkeit
- Ueberfaelliger Task ist auf einen Blick erkennbar
- Task in Done mit vergangener Faelligkeit ist **nicht** markiert
- Schmales Terminal (80 Spalten) → Layout bricht nicht, Titel bleibt lesbar
- Board ohne gesetzte Prioritaeten sieht aus wie vorher (keine leeren Marker)
- Farben in hellem und dunklem Terminal lesbar