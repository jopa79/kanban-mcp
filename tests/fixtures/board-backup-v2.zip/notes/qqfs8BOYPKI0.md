## Warum

`migrateDb()` laeuft heute in `openDb()` (`src/core/db.ts:30`) und damit
unbeaufsichtigt in jedem Pfad — auch im Sync-Hook, mitten in einem
Agenten-Turn. Eine Schema-Aenderung, die niemand angefordert hat und deren
Fehlschlag niemand sieht.

Ab v3: `openDb()` migriert nicht. Stattdessen prueft jeder Pfad und verweigert
den Start.

## Neue Funktion in `src/core/db.ts`

```ts
export function assertSchemaCurrent(db: Database, dbPath: string): void
```

Meldung bei Version < 3:

```
Board-Schema ist Version 2, benoetigt wird 3.
Datei: /pfad/.kanban/board.db
Fuehre 'kanban migrate' in /pfad aus. Ein Backup wird dabei automatisch angelegt.
```

Version **groesser** als erwartet (aelterer Client, neueres Board) braucht eine
eigene Meldung: `Board-Schema ist Version 4, dieser Client kann hoechstens 3.
Aktualisiere kanban-mcp.`

## Aufrufstellen

| Pfad | Verhalten |
|---|---|
| `src/cli/context.ts:28` (CLI + TUI) | Fehlermeldung, Exit 1 |
| `src/mcp/mcp-context.ts:23` und `:39` (**beide** Funktionen) | Fehler werfen → `isError: true` in der Tool-Antwort |
| `src/cli/commands/sync.ts` | Meldung auf **stderr**, **Exit 0** |
| `src/core/export-service.ts:30` (`exportBoard`) | Fehlermeldung, kein ZIP erzeugen |

**Sync ist die Ausnahme, die zaehlt.** Ein Hook, der einen Agenten-Turn mit
Exit 1 stoert, ist schaedlicher als ein ausgefallener Sync. Die bestehende
Konvention in `sync.ts` (still mit Exit 0 beenden, wenn kein Board da ist)
wird hier fortgefuehrt.

Ausgenommen: `kanban migrate` selbst, `initBoard()`, `importBoard()`
(erzeugt das Board direkt als v3).

## Verifikation

- v2-Board anlegen (Fixture), dann:
  - `kanban list` → Exit 1, Meldung nennt Pfad und Kommando
  - `kanban tui` → Meldung, kein Absturz
  - MCP `kanban_status` → `isError: true`, gleiche Meldung
  - `kanban sync` mit Payload → Exit 0, Meldung auf stderr, keine DB-Aenderung
  - `kanban export` → Fehler, kein ZIP auf der Platte
  - `kanban migrate` → laeuft
- Nach der Migration laufen alle Pfade wieder normal