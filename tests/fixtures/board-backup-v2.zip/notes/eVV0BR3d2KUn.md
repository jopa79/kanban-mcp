## Ausgangslage

`bunx tsc --noEmit` → **24 Fehler**, `bun test` → 148 pass, 0 fail.

## Kategorien

**1. `SQLQueryBindings` (14 Fehler, mechanisch)**
`db.run(sql, a, b, c)` statt `db.run(sql, [a, b, c])`.
Betroffen: `task-service.ts:33,144,171,193,194,228,236,273,281`,
`archive-service.ts:45,56,76,106`.

**2. Echter Laufzeitfehler (2 Fehler, wichtig)**
`tools-archive.ts:71,77` lesen `result.purgedCount` — `purgeArchive()`
(`archive-service.ts:118`) liefert `deletedCount`. Die MCP-Antwort enthaelt
heute `undefined`. **Kein reiner Typfehler, sondern ein sichtbarer Bug.**

**3. Null-Checks (4 Fehler)**
`tools-extras.ts:35` (`result.task` moeglicherweise null),
`dependency-view.tsx:52`, `tag-picker.tsx:39`,
`plugins/ralph-tracker/tests/*` (4 Stellen, `noUncheckedIndexedAccess`).

**4. Ink-Typ (1 Fehler)**
`tui.ts:12` — `fullScreen` existiert nicht in `RenderOptions`. Pruefen, ob die
Option in ink 6 anders heisst oder ersatzlos entfaellt. **Nicht einfach
wegcasten** — wenn die Option ignoriert wird, ist das eine Verhaltensaenderung
in der TUI, die jemand mal absichtlich gesetzt hat.

**5. `sync.ts:72`** — durch den Sync-Bugfix-Task erledigt, hier nicht doppelt anfassen.

## Verifikation

- `bunx tsc --noEmit` → 0 Fehler
- `bun test` → weiterhin 148 pass
- `kanban_purge_archive` ueber MCP aufrufen → Zahl statt `undefined` in der Antwort
- `kanban tui` startet und sieht aus wie vorher