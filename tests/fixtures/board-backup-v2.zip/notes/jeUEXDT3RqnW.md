## README — was heute falsch oder unvollstaendig ist

1. **Installationsweg fehlt.** Setup sagt `bun run src/index.ts init`, alle
   Beispiele darunter schreiben `kanban add ...`. Beides steht unverbunden
   nebeneinander. Mit dem `bin`-Eintrag und npm-Publish aufloesen.
2. **Bun ist Voraussetzung, nicht Detail.** Das Paket nutzt `bun:sqlite` und
   `Bun.$` — ohne Bun laeuft nichts. Gehoert nach oben, nicht ins Kleingedruckte.
   Sonst scheitert `npx kanban-mcp` mit einer unverstaendlichen Meldung.
3. **`kanban sync` kommt gar nicht vor** — obwohl es der Hook-Einstiegspunkt
   und der Grund fuer die halbe Architektur ist. Mit Hook-Eintrag fuer
   `.claude/settings.json` dokumentieren.
4. **`kanban migrate` dokumentieren**, inklusive Backup-Verhalten und der
   Tatsache, dass alle Pfade bei Schema < 3 verweigern.
5. **`kanban boards` dokumentieren**, inklusive der Aussage, dass MCP
   bewusst aussen vor bleibt.
6. **Tool-Tabelle ist veraltet:** `kanban_add_dependency` und
   `kanban_remove_dependency` fehlen (seit Commit `ae85192`). "16 Tools" oben
   im Dokument stimmt nicht mehr.
7. **`reportedBy` als Pflichtfeld** in der Tool-Tabelle sichtbar machen.
8. **Neuer Abschnitt Zustandsmaschine:** Kette vorwaerts strikt / rueckwaerts
   frei, Eintrittsspalten, `done` nur aus Review, Override nur im TUI.
   Mit Verweis auf `docs/decisions/0002-kein-force-in-mcp-tools.md`.
9. **`kanban add -c in-progress`** steht als Beispiel drin (Abschnitt CLI
   Commands) und **scheitert ab 0.2.0**. Korrigieren.
10. **Projektstruktur** um `migrate-v3.ts`, `transition-service.ts`,
    `sync-service.ts`, `registry-service.ts`, `docs/decisions/` ergaenzen.

## CHANGELOG

`[Unreleased]` → `## [0.2.0] - <Datum>`. Vier Breaking Changes, prominent oben:

```markdown
### Breaking

- Schema-Version 3: `kanban migrate` ist vor der ersten Nutzung erforderlich.
  Alle Pfade verweigern den Start bei aelterem Schema.
- MCP: `reportedBy` ist in schreibenden Tools jetzt Pflichtfeld
- `addTask` akzeptiert nur noch Spalten mit `allowEntry` (Default: Backlog, Todo)
- Verschiebungen koennen abgelehnt werden — die Kette ist vorwaerts strikt.
  `kanban done` scheitert, wenn der Task nicht in Review steht.
```

Der Schema-Punkt ist der wichtigste und fehlt in der urspruenglichen
Dreier-Liste aus der Grilling-Session.

Darunter `Added` / `Changed` / `Fixed` — der `sync`-Konstruktorfehler gehoert
unter `Fixed`, ebenso `purgedCount`/`deletedCount`.

## Verifikation

- Jedes README-Kommando einmal ausfuehren. Was nicht laeuft, steht falsch drin.
- CHANGELOG gegen `git log v0.1.0..HEAD` gegenpruefen — nichts vergessen