## Umfang

**`src/core/board-service.ts`** (40 Zeilen) — Konstruktor bekommt zusaetzlich
die `BoardConfig`:

| Methode | vorher | nachher |
|---|---|---|
| `getColumns()` | `SELECT * FROM columns ORDER BY position` | `config.columns` in **Array-Reihenfolge**, `position` = Index |
| `getColumn(id)` | SQL | `config.columns.find(c => c.id === id)` |
| `getTerminalColumn()` | SQL | `config.columns.find(c => c.isTerminal)` |
| `getColumnTaskCount(id)` | SQL | **bleibt SQL** — zaehlt Tasks, nicht Spalten |

**Nicht nach `position` sortieren.** Es gibt kein `position`-Feld in der Config
(K-1). Die Array-Reihenfolge ist die Ordnung; `getColumns()` gibt sie unveraendert
zurueck und setzt `position` aus dem Index. Ein `.sort()` waere hier ein Bug, der
sich erst zeigt, wenn jemand die Datei umsortiert.

**Neue Methode** fuer die Waisen-Behandlung in Paket 1:

```ts
getOrphanColumnIds(): string[]
```

`SELECT DISTINCT column_id FROM tasks WHERE archived = 0`, abzueglich der IDs
aus `config.columns`.

**Alle Konstruktionsstellen anpassen** (sechs):
- `src/cli/context.ts:30`
- `src/mcp/mcp-context.ts:25` und `:42`
- `src/tui/use-board.ts:14` (und `:23`, dort wird ein zweiter BoardService gebaut —
  bei der Gelegenheit zusammenfuehren)
- `src/core/export-service.ts:32`
- `tests/helpers.ts:29`

## Achtung

`use-board.ts:22-24` erzeugt in `loadData()` einen zweiten `BoardService` auf
derselben DB, obwohl `createServices()` bereits einen liefert. Der wird jetzt
zwangslaeufig auffallen, weil er auch die Config braucht. Aufraeumen statt
durchschleifen.

## Verifikation

- `bun test` — `tests/board-service.test.ts` laeuft unveraendert durch
  (dieselbe API, andere Quelle)
- `tests/task-extras.test.ts:74` erwartet 5 Spalten aus `getStatus()` → bleibt gruen
- **Spalten in `config.json` umsortieren → `getColumns()` liefert die neue
  Reihenfolge, `position` folgt dem Index**
- Manuell: Spalte in `config.json` umbenennen → TUI zeigt den neuen Namen ohne
  DB-Aenderung
- Manuell: `wipLimit` in `config.json` aendern → wirkt sofort