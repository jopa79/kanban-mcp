## Schema v3

```sql
CREATE TABLE transitions (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  task_id      TEXT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  from_column  TEXT,                 -- NULL = Task-Entstehung
  to_column    TEXT NOT NULL,
  reported_by  TEXT NOT NULL DEFAULT 'user',
  reason       TEXT,
  was_override INTEGER NOT NULL DEFAULT 0,
  created_at   TEXT NOT NULL
);
CREATE INDEX idx_transitions_task ON transitions(task_id, created_at);
```

**Genau ZWEI neue Felder auf `tasks`:**
```sql
priority  TEXT      -- 'high'|'medium'|'low'|NULL
due_date  TEXT      -- ISO 'YYYY-MM-DD' oder NULL
```

`tasks.column_id` **ohne** `REFERENCES columns(id)` (siehe ADR 0001).

## Zwei Felder gestrichen — nicht wieder aufnehmen

**`source_id` ist gestrichen.** TodoWrite liefert kein `id`-Feld (Plan
Abschnitt 0.1, belegt aus drei unabhaengigen Quellen). Ein clientseitig erzeugter
Content-Hash loest nichts — er aendert sich mit dem Content und ist damit
funktional identisch zum Titel-Matching. Kein Feld, kein `idx_tasks_source`.

**Kein `updated_by`** (K-3): `reportedBy` gilt nur fuer Transitions. Feld-Diffs
im Audit-Log wurden in der Grilling-Session verworfen ("dafuer gibt es git").

Zwei Felder statt vier in der riskantesten Migration des Projekts.

## Umfang

- `createSchema()` in `src/core/db.ts` auf v3 heben (fuer neue Boards)
- `Transition`-Typ und `TransitionRow` in `src/core/types.ts`, `rowToTransition`
- `TaskRow`/`Task` um `priority` und `dueDate` erweitern; `rowToTask` ergaenzen.
  Durchreichen durch die Services kommt erst in Paket 2 — hier nur das Feld,
  damit die Migration nur einmal laufen muss.

**Nicht** in diesem Task: die Migration selbst (P0-4), das Schreiben von
Transitions (Paket 1), CLI/MCP-Oberflaeche fuer priority/dueDate (Paket 2).

## Achtung `ON DELETE CASCADE`

`foreign_keys = ON` ist gesetzt (`db.ts:29`), der Cascade greift also wirklich.
`deleteTask` loescht damit die Historie mit. Gewollt — aber in einem Test
festhalten, damit es niemand fuer einen Bug haelt.

## Verifikation

- Neues Board via `kanban init` → `transitions` existiert, `tasks` hat genau die
  zwei neuen Felder, `schema_version` = 3
- **`tasks` hat kein `source_id`** — expliziter Test, damit es nicht
  versehentlich mitwandert
- Test: Task loeschen → zugehoerige Transitions weg
- Test: `PRAGMA foreign_key_check` liefert nichts