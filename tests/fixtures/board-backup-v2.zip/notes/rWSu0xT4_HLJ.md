## Entscheidung

**`reportedBy` gilt NUR fuer Transitions. Kein `updated_by` auf `tasks`.**

## Begruendung

In der Grilling-Session wurden Feld-Diffs im Audit-Log ausdruecklich verworfen:
*"dafuer gibt es git, keine halbe Versionsverwaltung im Board"*. Ein
`updated_by` waere der erste Schritt genau dorthin.

Zweiter Grund: es spart ein Feld in der riskantesten Migration des Projekts.

## Pflichtfeld in

- `kanban_add_task`
- `kanban_add_task_checked`
- `kanban_move_task`
- `kanban_complete_task`

## Nicht betroffen

- `kanban_update_task`, `kanban_delete_task`
- `kanban_init`, `kanban_archive_tasks`
- alle lesenden Tools

`kanban_restore_task` erzeugt eine Transition (`reason: "restore"`) und bekommt
`reportedBy` damit automatisch — das war der einzige wirklich fragliche Fall.

## Wirkung auf das Schema

P0-3 braucht **kein** zusaetzliches Feld auf `tasks`. Die Abhaengigkeit von
P0-3 auf diesen Task ist damit aufgeloest.

## Umgesetzt in

Plan-Datei Abschnitt 3.3, Tasks P0-3 und P1-3.